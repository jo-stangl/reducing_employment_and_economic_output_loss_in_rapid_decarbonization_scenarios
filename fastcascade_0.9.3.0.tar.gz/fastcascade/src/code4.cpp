// [[Rcpp::depends(RcppArmadillo)]]
// #define ARMA_64BIT_WORD
#include <RcppArmadillo.h>
using namespace Rcpp;




// helper function "each_row" for sparse matrix (actually each_col?)
arma::sp_mat my_each_rowGL(arma::sp_mat A, arma::vec v){
  arma::sp_mat::const_iterator start = A.begin();
  arma::sp_mat::const_iterator end   = A.end();

  arma::sp_mat dummy(A);

  for(arma::sp_mat::const_iterator it = start; it != end; ++it)
  {
    // Rcpp::Rcout << "hier 3, itrow " << it.row() << " it col " << it.col(); // << "\n";
    // Rcpp::Rcout << " psup_h " << psup_h(it.row(), it.col());
    // Rcpp::Rcout << " hdiff " << hdiff(it.row()) << "\n";
    dummy(it.row(),it.col()) *= arma::as_scalar(v(it.row()));
  }
  return dummy;
}



// order inputs for compatibility with R-function:
// cascade_dynamics_leon1(Lambda_d, Lambda_u,  psup, psup_market, def_index, n, m,
//  eps, prodfun_sets, mix_prodfun, track_h, h_weights, out_str,
//  p_market, substitution, track_conv, conv_type)


// could add a psi_i here to make it unequal to zero
// bool track_conv,
// int conv_type

// --------------- TODO: ---------------
// track convergence option
// ensure consistency of convergence criteria
// cleanup / better comments
// write unit test


// order inputs for compatibility with R-function:
// cascade_dynamics_leon1(Lambda_d, Lambda_u,  psup, psup_market, def_index, n, m,
//  eps, prodfun_sets, mix_prodfun, track_h, h_weights, out_str,
//  p_market, substitution, track_conv, conv_type)


// could add a psi_i here to make it unequal to zero
// bool track_conv,
// int conv_type

// --------------- TODO: ---------------
// track convergence option
// ensure consistency of convergence criteria
// cleanup / better comments
// write unit test


//' calculate cascade for a set of nodes using the Psi set up
//' @param Lambda_d matrix for downstream contagion
//' @param Lambda_u matrix for upstream contagion
//' @param psi_mat columns containing the amount of shock nodes receive
//' @param psi_mat_up columns containing the amount of shock nodes receive in the upstream direction. if false upstream and downstream shocks are the same. if submitted psi_mat determines the downstream shocks.
//' @param n number of firms
//' @param m number of products / industry sectors
//' @param substitution logical (TRUE/FALSE) specifies if suppliers are replaceable
//' @param psup binary n times m matrix specifying company i is from sector k in (1,...m)
//' @param h_weights n times k matrix where k is the number of different company weights
//' @param eps numeric specifying the convergence threshold
//' @param h_mat_round numeric that specifies to how many digitis h_mat will be rounded (if track_h = TRUE), by default it rounds to one more digit than then eps, i.e. eps = 10^-2 will lead to h_mat_round = 3
//' @param p_market_cons numeric vector of length n specifying the industry for market share calculation
//' @param out_str vector containing the outstrength of firms
//' @param psup_market same as psub but for market share calculation
//' @param track_h logical to save the single h_vectors of the cascade
//' @param track_sector_impacts logical to save sector level impacts of shocks
//' @param track_conv, tracks convergences i.e. how many iterations and what was the overall relative esri change
//' @param conv_type, use delta percetage production loss or relative esri change as stopping criterion
//' @param psup_sec_impact binary n times m matrix for sector impact calculation (determines aggregation level)
//' @param sec_aggr_weights vector specifying the weights of firms for aggregation to the sector level (e.g. value added)
//' @param sec_aggr_weights_up vector specifying the weights of firms for aggregation to the sector level for upstream shocks. as default in_strength is used (e.g. value added)
//' @param sectors_cons,  the sectors from p vector in consecutive order
//' @param p_cons_uni_ess_mat,  n... integer vec, contains the indices to unique essential non essential sets
//' @param uni_ess_mat_sec  m x m_uniq integer, 2 means essential, 1 non essential, 0, no impact, contains m_uniq columns where each column represents a essential non essential set for a group of sectors with unique essential non essential sets
//' @return outlist a list with numeric vectors specifying the cascade size of each firm
//' @export
// [[Rcpp::export]]
arma::sp_mat GL_cascade_dynamics_cpp(arma::sp_mat Lambda_d,  // N x N matrix of doubles, containing the sector specific inputs
                                      arma::sp_mat Lambda_u,  // O x O matrix of doubles, containg the sector specific outputs?
                                      arma::sp_mat psi_mat,   // N x k matrix where column k gives default scenario k --> Identity Matrix calculates single firm defaults
                                      arma::sp_mat psi_mat_up,   // N x k matrix where column k gives default scenario k --> Identity Matrix calculates single firm defaults
                                      int n,                  // N ... integer, number of firms
                                      int m,                  // M ... integer, number of sectors
                                      bool substitution,      // turn substitution factor on/off
                                      arma::sp_mat psup,      //  matrix of doubles, containing ???
                                      arma::mat h_weights,    // column vector of  contains the weights, e.g. employees, turnover, etc.
                                      double eps,             // double, convergence limit
                                      double h_mat_round,     // double or int actual, determines to how many digitis h_mat will be rounded
                                      arma::uvec p_market_cons,    // p_market_cons[i] ... the industry on nace 4 level of company i to asses replaceability by market share is used for the supplier replaceability factor ; vector of unsigned integers, serves for indexing later!
                                      arma::colvec out_str,   // out strength, double, vector of size n, for calculating market impact
                                      arma::sp_mat psup_market,// sparse matrix of 0 and 1, to know which matices to include in market impact
                                      bool track_h,           // determines if single h_vectors are output
                                      bool track_sector_impacts, // determines if sector level shocks received should be outputted
                                      bool track_conv, // tracks convergences i.e. how many iterations and what was the overall relative esri change
                                      double conv_type, // use delta percetage production loss or relative esri change as stopping criterion
                                      arma::sp_mat psup_sec_impact, // mat n times m gives one if firm i \in n is member of sector j \in m
                                      arma::vec sec_aggr_weights, // specifies the weight for each firm for the aggregation to the sector level
                                      arma::vec sec_aggr_weights_up, // specifies the weight for each firm for the aggregation to the sector level
                                      arma::uvec sectors_cons,  // the sectors from p vector in consecutive order
                                      arma::uvec p_cons_uni_ess_mat, // n... integer vec, contains the indices to unique essential non essential sets
                                      arma::mat uni_ess_mat_sec)     // m x m_uniq integer, 2 means essential, 1 non essential, 0, no impact, contains m_uniq columns where each column represents a essential non essential set for a group of sectors with unique essential non essential sets
{

  // check how many companies need to be calculated on this node
  int n_def = psi_mat.n_cols;
  int n_weights = h_weights.n_cols;
  int n_uni_ess_mat_secs = uni_ess_mat_sec.n_cols;
  

  h_weights = h_weights.each_row() / arma::sum(h_weights,0);
  
  sec_aggr_weights = sec_aggr_weights / arma::sum(sec_aggr_weights);
  sec_aggr_weights_up = sec_aggr_weights_up / arma::sum(sec_aggr_weights_up); // upstream aggregation weights

  
  // output matrices for Systemic Risk Index and convergence statitics
  // arma::mat ESRI = arma::zeros<arma::mat>(n_def,3*n_weights);
  arma::mat ESRI(n_def, 3*n_weights, arma::fill::zeros);

  //       ESRI_conv <- Matrix(0, ncol=3, nrow=n_def)
  arma::sp_mat ESRI_conv(n_def, 3); // empty place holder for output structure

  // outputting single company shocks
  arma::sp_mat hd_T_mat(n, n_def); //track h_d of downstream affected nodes
  arma::sp_mat hu_T_mat(n, n_def); //track h_u of upstream affected nodes

  // outputting sector impacts of shocks
  arma::mat p_sector_shares(psup_sec_impact.n_rows, 1);
  p_sector_shares = sec_aggr_weights.as_row() * psup_sec_impact;
  p_sector_shares.replace(0, 1);
  
  // upstream shock weights
  arma::mat p_sector_shares_up(psup_sec_impact.n_rows, 1);
  p_sector_shares_up = sec_aggr_weights_up.as_row() * psup_sec_impact; 
  p_sector_shares_up.replace(0, 1);
  

  arma::mat sec_d_mat(n_def, psup_sec_impact.n_cols, arma::fill::zeros);
  arma::mat sec_u_mat(n_def, psup_sec_impact.n_cols, arma::fill::zeros);
  arma::mat sec_du_mat(n_def, psup_sec_impact.n_cols, arma::fill::zeros);


  arma::mat sec_d_mat_init(n_def, psup_sec_impact.n_cols, arma::fill::zeros);
  arma::mat sec_u_mat_init(n_def, psup_sec_impact.n_cols, arma::fill::zeros);
  arma::mat sec_du_mat_init(n_def, psup_sec_impact.n_cols, arma::fill::zeros);
  
  
  ////////////////////////////////////
  ////// CASCADE NODE i Default /////
  //////////////////////////////////
  for(int i = 0; i < n_def; i++){   // maybe i need to adapt this for arbitrary n_def

    if((i % 100)==0){
      Rcpp::Rcout << "Iteration " << i << "\n"; //  progress report for single core
    }


    ////////////////////////////////////
    ////// CASCADE INITIALISATION /////
    //////////////////////////////////


    //arma::uword k = def_index(i)-1; // node ID which is shocked in iteration i

    // initialize h-variables
    // arma::colvec h_tm1_d(n, arma::fill::ones);
    // arma::colvec h_tm1_u(n, arma::fill::ones);

    arma::colvec h_t_d(n, arma::fill::ones);
    arma::colvec h_t_u(n, arma::fill::ones);

    arma::colvec h_tp1_d(n, arma::fill::ones);
    arma::colvec h_tp1_u(n, arma::fill::ones);

    arma::colvec psi_d(n, arma::fill::ones);
    psi_d = arma::ones(n) - psi_mat.col(i);
    
    arma::colvec psi_u(n, arma::fill::ones);
    psi_u = arma::ones(n) - psi_mat_up.col(i);
    
    h_t_d = psi_d;
    h_t_u = psi_u;

    // arma::colvec psi_init(n, arma::fill::zeros);
    // psi_init = psi_mat.col(i);

    // //old version
    //   h_t_d(k) = 0;
    //   h_t_u(k) = 0;
    //   h_tp1_d(k) = 0;
    //   h_tp1_u(k) = 0;

    // pi_tm1 indicates how much  of input k for company i are still available in percent
    // arma::mat pi_tm1 = arma::ones<arma::mat>(n,m),
    //   pi_t = arma::ones<arma::mat>(n,m); // Armadillo matrix? rep 1? also m
    //
    // pi_tm1.row(k).fill(0); // defaulted node does not have inputs

    // arma::mat pi_tm1(n, m, arma::fill::ones);
    arma::mat pi_t(n, m, arma::fill::ones);


    // init market share vector
    arma::vec p_share = arma::ones<arma::vec>(n);


    // convergence test
    // if(track_conv==TRUE){
    //   SI_conv_t <- (1-pmin(h_t_d, h_t_u)) %*% h_weights[,1]
    //   t <- 0
    // }
    double SI_conv_tm1 = 0; 
    double SI_conv_t = 0; 
    
    SI_conv_t = arma::as_scalar(arma::trans(h_weights.col(0)) * (arma::ones<arma::vec>(n) - arma::min(h_t_d, h_t_u)));
    
    

    //////////////////////////////////
    ////// CASCADE ITERATIONS ///////
    /////////////////////////////////

    bool crit = TRUE;
    // iterative updates for up and downstream
    double t = 0;
    while(crit == TRUE){

       // Rcpp::Rcout << "Iter while " << t << "\n"; //  progress report for single core
      

      if(substitution){  // change this!!!
        arma::vec p_availability(m);
        p_availability = psup_market.t() * (h_t_d % out_str);  // does this make sense? how are the dimensions here?!? dimension (N % N) * NxM -> M
        // p_availability.replace(0,1);
        p_availability = (p_availability <= pow(10, -10)) % arma::ones<arma::vec>(m) + (p_availability > pow(10, -10)) % p_availability;        
        p_share = out_str / p_availability(p_market_cons);
        p_share = arma::min(arma::ones<arma::vec>(n), p_share);
      }
      else{
        p_share = arma::ones<arma::vec>(n);
      }

      // downstream update

      // Lambda_d * p_share
      arma::sp_mat Lambda_d_share(Lambda_d);
      Lambda_d_share = my_each_rowGL(Lambda_d, p_share);

      // // p_sup * (h_t_d - h_tm1_d)
      // arma::vec hdiff(h_t_d);
      // hdiff -= h_tm1_d;
      // arma::sp_mat psup_h(psup);
      // psup_h = my_each_rowGL(psup, hdiff); // actually columns multiplied by h_diff
      //
      // pi_t = arma::max(pi_tm1 + (Lambda_d_share.t() * psup_h), arma::zeros<arma::sp_mat>(n,m));

      // time conistent pi update when p_share is used
      arma::sp_mat psup_h(psup);
      psup_h = my_each_rowGL(psup, arma::ones<arma::vec>(n)-h_t_d); // actually columns multiplied by h_diff
      pi_t = arma::mat(n,m, arma::fill::ones) - (trans(Lambda_d_share) * psup_h);

      // Rcpp::Rcout << "pi_t" << "\n" << pi_t.t() << "\n"; //  progress report for single core
      
      
      // GL evaluation, i.e. update for each unique set of essential non essential inputs the GL pf for all firms in the sectors belinging to this essential non essential sets
      
      for(int k = 0; k < n_uni_ess_mat_secs; k++){
        
        // Rcpp::Rcout << "Iteration " << k << "\n"; //  progress report for single core
        
        
        arma::mat leo_inputs(sum(p_cons_uni_ess_mat==k), 1, arma::fill::ones);
        arma::mat lin_inputs(sum(p_cons_uni_ess_mat==k), 1, arma::fill::ones);
        
        if(arma::sum(uni_ess_mat_sec.col(k) == 2) > 0){ 
          leo_inputs = arma::min(pi_t.submat( arma::find(p_cons_uni_ess_mat==k) , arma::find(uni_ess_mat_sec.col(k)==2) ) ,1);
        }
        
        if(arma::sum(uni_ess_mat_sec.col(k) == 1) > 0){ 
          lin_inputs = arma::sum(pi_t.submat( arma::find(p_cons_uni_ess_mat==k) , arma::find(uni_ess_mat_sec.col(k)==1) ) ,1) - arma::sum(uni_ess_mat_sec.col(k) == 1) + 1;
        }
        
        // Rcpp::Rcout << "leo_inputs " << "\n" << leo_inputs << "\n"; //  progress report for single core
        // Rcpp::Rcout << "lin_inputs " << "\n" << lin_inputs << "\n"; //  progress report for single core
        
        
        h_tp1_d.elem(arma::find(p_cons_uni_ess_mat==k)) =  arma::max(arma::zeros<arma::vec>(lin_inputs.n_elem),arma::min( psi_d.elem(arma::find(p_cons_uni_ess_mat==k)), 
                     arma::min(lin_inputs, leo_inputs )));
        
        // Rcpp::Rcout << "h_tp1_d" << "\n" << h_tp1_d << "\n"; //  progress report for single core
        
      }
      
      // Rcpp::Rcout << "h_tp1_d" << "\n" << h_tp1_d.t() << "\n"; //  progress report for single core
      
      
      // upstream m
      // h_tp1_u = arma::max(arma::zeros<arma::vec>(n), h_t_u +  Lambda_u * (h_t_u - h_tm1_u));
      h_tp1_u = arma::max(arma::zeros<arma::vec>(n), arma::min(psi_u, arma::ones<arma::vec>(n) - Lambda_u * (arma::ones<arma::vec>(n) - h_t_u ) ) );
      
      

      if(track_conv == TRUE){
        t = t + 1;
        SI_conv_tm1 = SI_conv_t;
        SI_conv_t = arma::as_scalar( arma::trans(arma::ones<arma::vec>(n) - arma::min(h_tp1_d, h_tp1_u)) * h_weights.col(0) );
        // Rcpp::Rcout << SI_conv_tm1 << " " << SI_conv_t << " " << SI_conv_t / SI_conv_tm1 << " "; //  progress report for single core
        
      }
      
      if(conv_type == 1){
        crit = arma::as_scalar(arma::max( arma::max(-h_tp1_d + h_t_d, -h_tp1_u + h_t_u) ) ) > eps;
      }else{
        crit = ( (SI_conv_t / SI_conv_tm1) > (1 + eps));
        // Rcpp::Rcout << ( (SI_conv_t / SI_conv_tm1) > (1 + eps)) << "\n" ; //  progress report for single core
        
      }
      
      
      // // stopping criterion
      // if(arma::as_scalar(arma::max( arma::max(-h_tp1_d + h_t_d, -h_tp1_u + h_t_u) ) ) < eps){
      //   crit = FALSE;
      // }
      // else{
      //   t++;
      // }
      
      
//      h_tm1_d = h_t_d;
      h_t_d = h_tp1_d;

//      h_tm1_u = h_t_u;
      h_t_u = h_tp1_u;

      // Rcpp::
      // Rcout << "h_t_d" << "\n" << h_t_d.t() << "\n"; //  progress report for single core
      
    }

    // # save single h vectors 1 - h to be sparse
    //  if(track_h == TRUE){ hd_T_mat[,i] <- 1-h_t_d; hu_T_mat[,i] <- 1-h_t_u }
    if(track_h == TRUE){
      hd_T_mat.col(i) = arma::vec(n, arma::fill::ones) - round(h_t_d * pow(10 , h_mat_round)) / pow(10 , h_mat_round);
      hu_T_mat.col(i) = arma::vec(n, arma::fill::ones) - round(h_t_u * pow(10 , h_mat_round)) / pow(10 , h_mat_round);
    }
    
    if(track_conv == TRUE){ 
      ESRI_conv(i,0) = SI_conv_tm1;
      ESRI_conv(i,1) = SI_conv_t;
      ESRI_conv(i,2) = t;
      }
    

    // arma::vec init_sec_shock(psup_sec_impact.n_cols, arma::fill::ones);
    // init_sec_shock = (((sec_aggr_weights % psi_mat.col(i)).as_row() * psup_sec_impact).as_col()) / p_sector_shares.as_col();
    // 
    // arma::vec init_sec_shock_up(psup_sec_impact.n_cols, arma::fill::ones);
    // init_sec_shock_up = (((sec_aggr_weights_up % psi_mat_up.col(i)).as_row() * psup_sec_impact).as_col()) / p_sector_shares_up.as_col();
    // 
    // arma::vec init_sec_shock_up_du(psup_sec_impact.n_cols, arma::fill::ones);
    // init_sec_shock_up_du = (((sec_aggr_weights % psi_mat_up.col(i)).as_row() * psup_sec_impact).as_col()) / p_sector_shares.as_col();
    
    
    if(track_sector_impacts == TRUE){
      
      sec_d_mat_init.row(i)  = (((sec_aggr_weights % psi_mat.col(i)).as_row() * psup_sec_impact).as_row()) / p_sector_shares.as_row();
      sec_u_mat_init.row(i)  = (((sec_aggr_weights_up % psi_mat_up.col(i)).as_row() * psup_sec_impact).as_row()) / p_sector_shares_up.as_row();
      sec_du_mat_init.row(i)  = (((sec_aggr_weights % psi_mat_up.col(i)).as_row() * psup_sec_impact).as_row()) / p_sector_shares.as_row();
      
      
      sec_d_mat.row(i) = ((((arma::ones(n)-h_t_d) % sec_aggr_weights).as_row() * psup_sec_impact)/p_sector_shares).as_row() -
        sec_d_mat_init.row(i);
      sec_u_mat.row(i) = ((((arma::ones(n)-h_t_u) % sec_aggr_weights_up).as_row() * psup_sec_impact)/p_sector_shares_up).as_row() -
        sec_u_mat_init.row(i);
      sec_du_mat.row(i) = ((((arma::ones(n)-arma::min(h_t_d, h_t_u)) % sec_aggr_weights).as_row() * psup_sec_impact)/p_sector_shares).as_row() -
        arma::max(sec_d_mat_init.row(i), sec_du_mat_init.row(i));
    }


    // ESRI(i,0) = arma::as_scalar(arma::min(h_t_d, h_t_u).t() * h_weights);
    // ESRI(i,1) = arma::as_scalar(h_t_d.t() * h_weights);
    // ESRI(i,2) = arma::as_scalar(h_t_u.t() * h_weights);
    //ESRI(i, arma::span(0, n_weights-1))             = arma::min(h_t_d, h_t_u).t() * h_weights;
    //ESRI(i, arma::span(n_weights, 2*n_weights-1))   = h_t_d.t() * h_weights;
    //ESRI(i, arma::span(2*n_weights, 3*n_weights-1)) = h_t_u.t() * h_weights;
    arma::mat mindownup = arma::ones<arma::mat>(n,3) - arma::join_horiz(arma::min(h_t_d, h_t_u), h_t_d, h_t_u);
    arma::mat weighted  =  h_weights.t() * mindownup;
    ESRI.row(i) = weighted.as_row();

  }


  // convert results into sparse matrices for outputting
  arma::sp_mat ESRI_sp(ESRI);

  arma::sp_mat h_T_mat = arma::join_rows(hd_T_mat.t(),
                                         hu_T_mat.t());

  arma::mat sec_mats = arma::join_rows(sec_d_mat,
                                       sec_u_mat,
                                       sec_du_mat
                                       );

  arma::mat sec_mats2 = arma::join_rows(sec_mats,
                                        sec_d_mat_init,
                                        sec_u_mat_init,
                                        sec_du_mat_init);
  
  
  arma::sp_mat sec_mats_sp(sec_mats2);


  // select which things need to be outputted

  arma::sp_mat outlist = ESRI_sp;

  if(track_h == TRUE){
    outlist  = arma::join_rows(outlist,
                               h_T_mat);
  }

  // bool track_conv = FALSE;
  if(track_conv == TRUE){
    outlist  = arma::join_rows(outlist,
                               ESRI_conv);
  }

  if(track_sector_impacts == TRUE){
    outlist  = arma::join_rows(outlist,
                               sec_mats_sp);
  }

  return outlist;

  // // specify the output
  // Rcpp::List outlist(3);
  // outlist = Rcpp::List::create(Rcpp::Named("ESRI") = ESRI);
  // // earlier: ESRI = arma::ones<arma::mat>(n_def,3*n_weights)-ESRI;
  //
  // if(track_h ==TRUE){
  //   outlist = Rcpp::List::create(Rcpp::Named("ESRI") = ESRI,
  //                                Rcpp::Named("hd_T_mat") = hd_T_mat,
  //                                Rcpp::Named("hu_T_mat") = hu_T_mat);
  // }
  //
  // if(track_sector_impacts ==TRUE){
  //   outlist = Rcpp::List::create(Rcpp::Named("ESRI") = ESRI,
  //                                Rcpp::Named("sec_d_mat") = sec_d_mat,
  //                                Rcpp::Named("sec_u_mat") = sec_u_mat,
  //                                Rcpp::Named("sec_du_mat") = sec_du_mat);
  // }
  //
  // if( (track_sector_impacts ==TRUE)&& track_h ==TRUE){
  //   outlist = Rcpp::List::create(Rcpp::Named("ESRI") = ESRI,
  //                                Rcpp::Named("hd_T_mat") = hd_T_mat,
  //                                Rcpp::Named("hu_T_mat") = hu_T_mat,
  //                                Rcpp::Named("sec_d_mat") = sec_d_mat,
  //                                Rcpp::Named("sec_u_mat") = sec_u_mat,
  //                                Rcpp::Named("sec_du_mat") = sec_du_mat);
  // }
  //
  // return outlist;
}







